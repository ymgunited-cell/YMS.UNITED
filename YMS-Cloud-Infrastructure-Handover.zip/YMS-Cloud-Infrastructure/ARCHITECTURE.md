# ARCHITECTURE — YMS Cloud (conceptual only)

From product constraints discussed across CSP/YMS work (not a deployed system):

- Prefer zero monetary cost for AI
- Local Ollama / LM Studio as primary compute
- Docker sandbox for untrusted build/run when enabled
- Replit-style hosting mentioned for YMS AI chat app
- No verified multi-region free-cloud worker fleet in recovered files

Do not implement this architecture from this document alone without explicit product authorization.
