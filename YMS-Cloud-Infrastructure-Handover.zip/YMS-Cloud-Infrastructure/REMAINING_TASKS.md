# REMAINING_TASKS

1. Confirm whether any cloud repo exists outside this environment (user backups).
2. If none: treat cloud as greenfield under separate project charter.
3. Do not conflate CSP Docker sandbox flags with a full cloud platform.
