# YMS_CURRENT_STATE (evidence-based)

## Code Studio Pro

| Field | Value |
|-------|--------|
| Latest phase **on disk this session** | Early baseline (archive date 2026-08-15) |
| Latest phase **claimed in prior sessions** | 12.9 Final Acceptance docs / pure tests |
| Disk proof of 12.9 tree | **Absent** |
| Git commit | N/A |
| Implemented in recovered tree | Workspace, api-server skeleton, mockup-sandbox, db, api-client-react, api-zod, api-spec |
| Incomplete relative to conversation | Full IDE, AI orchestrator packages, Phase 11–12 features |
| Known blocker (historical) | Full install/typecheck often ENVIRONMENT BLOCKED; missing packages in some snapshots |
| api-client-react in **this** early ZIP | **Present** under `lib/api-client-react/` |

## YMS AI Standalone

| Field | Value |
|-------|--------|
| Source | `YMS_AI_HANDOFF_COMPLETE.zip` → `YMS_AI_SOURCE.zip` |
| Handoff date | 2026-10-26 |
| State | Chat-first app + API + zero-cost gate + disabled sandbox |
| Production parity | Not certified by original handoff |

## YMS Cloud

| Field | Value |
|-------|--------|
| Implementation | **Not recovered** |
| Classification | Planned / conceptual |
